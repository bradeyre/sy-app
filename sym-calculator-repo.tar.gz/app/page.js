"use client";import{useEffect as _,useMemo as se,useRef as le,useState as m}from"react";import{formatZAR as B}from"@/lib/format";import{validateIdOrPassport as ft,digitsOnly as Me}from"@/lib/validation";import{isCourierCollectionDay as bt}from"@/lib/publicHolidays";function V(e){if(typeof window>"u")return e;const n=new URLSearchParams(window.location.search).get("site");if(!n)return e;const a=e.includes("?")?"&":"?";return`${e}${a}site=${encodeURIComponent(n)}`}const s={CATEGORY:"category",MODEL:"model",QUOTE:"quote",FAULTS:"faults",ACCESSORIES:"accessories",EXTRAS:"extras",PAYMENT:"payment",CALCULATING:"calculating",REVEAL:"reveal",DETAILS:"details",DONE:"done"},ie=[s.CATEGORY,s.MODEL,s.QUOTE,s.PAYMENT,s.DETAILS],ht={[s.CATEGORY]:"Device",[s.MODEL]:"Model",[s.QUOTE]:"Condition",[s.PAYMENT]:"Payment",[s.DETAILS]:"Your info"},$e={[s.FAULTS]:s.QUOTE,[s.ACCESSORIES]:s.QUOTE,[s.EXTRAS]:s.QUOTE,[s.CALCULATING]:s.PAYMENT,[s.REVEAL]:s.PAYMENT},gt={Sealed:"Brand new and unopened, still in its original packaging.",Mint:"Looks and works like new, no visible marks or faults.",Good:"Normal signs of everyday use, but fully working with no faults.",Poor:"Heavily used, or has a real fault, e.g. a cracked screen, a non-working button or port, or reduced battery health. Note: some faults may mean we're not able to buy back that particular item, you'll see if that applies on the next step."},je={Phone:<svg viewBox="0 0 24 24"fill="none"stroke="currentColor"strokeWidth="1.6"strokeLinecap="round"strokeLinejoin="round">
      <rect x="7"y="2"width="10"height="20"rx="2"/>
      <line x1="11"y1="18"x2="13"y2="18"/>
    </svg>,Laptop:<svg viewBox="0 0 24 24"fill="none"stroke="currentColor"strokeWidth="1.6"strokeLinecap="round"strokeLinejoin="round">
      <rect x="4"y="4"width="16"height="11"rx="1"/>
      <path d="M2 18.5h20l-1.6 2.2a1 1 0 0 1-.8.4H4.4a1 1 0 0 1-.8-.4z"/>
    </svg>,Desktop:<svg viewBox="0 0 24 24"fill="none"stroke="currentColor"strokeWidth="1.6"strokeLinecap="round"strokeLinejoin="round">
      <rect x="4"y="3"width="16"height="11"rx="1"/>
      <line x1="12"y1="14"x2="12"y2="18"/>
      <line x1="8"y1="20.5"x2="16"y2="20.5"/>
    </svg>,Tablet:<svg viewBox="0 0 24 24"fill="none"stroke="currentColor"strokeWidth="1.6"strokeLinecap="round"strokeLinejoin="round">
      <rect x="4"y="3"width="16"height="18"rx="2"/>
      <line x1="10"y1="18"x2="14"y2="18"/>
    </svg>,Watch:<svg viewBox="0 0 24 24"fill="none"stroke="currentColor"strokeWidth="1.6"strokeLinecap="round"strokeLinejoin="round">
      <rect x="8"y="6.5"width="8"height="11"rx="2.2"/>
      <line x1="10"y1="2"x2="10"y2="6.5"/>
      <line x1="14"y1="2"x2="14"y2="6.5"/>
      <line x1="10"y1="17.5"x2="10"y2="22"/>
      <line x1="14"y1="17.5"x2="14"y2="22"/>
    </svg>,Earphone:<svg viewBox="0 0 24 24"fill="none"stroke="currentColor"strokeWidth="1.6"strokeLinecap="round"strokeLinejoin="round">
      <circle cx="7"cy="8.5"r="3"/>
      <line x1="7"y1="11.5"x2="7"y2="18"/>
      <circle cx="17"cy="8.5"r="3"/>
      <line x1="17"y1="11.5"x2="17"y2="18"/>
    </svg>,Console:<svg viewBox="0 0 24 24"fill="none"stroke="currentColor"strokeWidth="1.6"strokeLinecap="round"strokeLinejoin="round">
      <path d="M6 9h4M8 7v4"/>
      <circle cx="16.5"cy="8.5"r="0.9"fill="currentColor"stroke="none"/>
      <circle cx="14.5"cy="10.5"r="0.9"fill="currentColor"stroke="none"/>
      <path d="M5.5 9c-2 0-3.2 2-3 4.3.2 2 1.5 4.2 3.3 4.2 1.3 0 1.7-1.2 2.7-2 .8-.6 1.6-.9 2.5-.9h2c.9 0 1.7.3 2.5.9 1 .8 1.4 2 2.7 2 1.8 0 3.1-2.2 3.3-4.2.2-2.3-1-4.3-3-4.3z"/>
    </svg>},Q={Phone:{bg:"bg-[#00a2ff]/10",text:"text-[#00a2ff]"},Laptop:{bg:"bg-[#7c6ff0]/10",text:"text-[#7c6ff0]"},Desktop:{bg:"bg-[#14b8a6]/10",text:"text-[#14b8a6]"},Tablet:{bg:"bg-[#ec4899]/10",text:"text-[#ec4899]"},Watch:{bg:"bg-[#f59e0b]/10",text:"text-[#f59e0b]"},Earphone:{bg:"bg-[#22c55e]/10",text:"text-[#22c55e]"},Console:{bg:"bg-[#6366f1]/10",text:"text-[#6366f1]"}},xt={Sealed:"#00a2ff",Mint:"#22c55e",Good:"#f59e0b",Poor:"#9ca3af"},Ge=["#00a2ff","#22c55e","#facc15","#38bdf8"];export default function yt(){const[e,n]=m(s.CATEGORY),[a,l]=m(null),[f,p]=m(!0),[i,u]=m(null),[r,b]=m(null),[A,x]=m(""),[g,z]=m(null),[T,v]=m(null),[j,c]=m(null),[w,R]=m(null),[P,Te]=m(null),[ze,G]=m([]),[Se,H]=m([]),[J,Z]=m(""),[Ee,X]=m(""),[Ue,Ae]=m({faultDeductionTotal:0,appliedFaults:[],pendingReviewFaults:[]}),[ke,we]=m([]),[Ce,ve]=m(""),[M,qe]=m("consignment"),[D,ee]=m([]),[We,Y]=m(!1),[De,L]=m(null),[Oe,Fe]=m({fullName:"",phone:"",email:"",address:"",suburb:"",city:"",province:"",postalCode:"",residentialAddress:!0,preferredCollectionDate:"",notes:"",idNumber:"",ageConfirmed:!1,termsAccepted:!1,privacyAccepted:!1,idDocumentPath:"",selfiePath:"",bankName:"",accountType:"",branchCode:"",accountNumber:"",website:""}),[Ve,Qe]=m({status:"idle",fileName:"",error:null}),[Ke,He]=m({status:"idle",fileName:"",error:null}),[Je,Pe]=m(!1),[Ze,Xe]=m(null),Le=le(null),te=le(null),ye=le(!1);_(()=>{Le.current=Date.now()},[]),_(()=>{console.log("%cPsst, poking around the code?","color:#00a2ff;font-weight:bold;font-size:14px;"),console.log("We like that. If you build things too, say hi: sell@epicdeals.co.za")},[]),_(()=>{if(!te.current||typeof ResizeObserver>"u")return;const t=te.current,o=()=>{window.parent?.postMessage({type:"epic-calc-resize",height:t.scrollHeight},"*")},d=new ResizeObserver(o);return d.observe(t),o(),()=>d.disconnect()},[e,a,r,j,D]),_(()=>{fetch(V("/api/categories")).then(t=>t.json()).then(t=>{if(t.error)throw new Error(t.error);l(t.categories)}).catch(t=>L(t.message)).finally(()=>p(!1)),fetch("/api/settings").then(t=>t.json()).then(t=>{if(t.error)throw new Error(t.error);u(t)}).catch(t=>L(t.message))},[]),_(()=>{e===s.CATEGORY&&!f&&a&&a.length===1&&D.length===0&&!ye.current&&(ye.current=!0,et(a[0]))},[e,f,a]);function et(t){z(t),b(null),x(""),Y(!0),L(null),fetch(V(`/api/models?type=${encodeURIComponent(t.type)}`)).then(o=>o.json()).then(o=>{if(o.error)throw new Error(o.error);const d=[...o.models].sort((k,N)=>k.label.localeCompare(N.label));b(d),n(s.MODEL)}).catch(o=>L(o.message)).finally(()=>Y(!1))}function tt(t){v(t),c(null),R(null),Y(!0),L(null),fetch(V(`/api/quote?model=${encodeURIComponent(t.model)}`)).then(o=>o.json()).then(o=>{if(o.error)throw new Error(o.error);c(o.capacities),o.capacities.length===1&&R(o.capacities[0]),n(s.QUOTE)}).catch(o=>L(o.message)).finally(()=>Y(!1))}function U(t,o){return(i?.conditionFaults?.[t]||[]).filter(k=>k.type==="battery_threshold"?o!=="Sealed":o==="Good"||o==="Poor")}function q(t,o){return(i?.freeTextFaultCategories||[]).includes(t)&&(o==="Good"||o==="Poor")}function ot(t){const d=(i?.aiDeductionCategories||[]).includes(g.type)&&t.condition==="Poor"?w.conditions.find(C=>C.condition==="Good"):null,k={key:`${T.model}-${w.capacity}-${t.condition}-${D.length}`,type:g.label,categoryType:g.type,model:T.label,capacity:w.capacity,condition:t.conditionLabel,conditionRaw:t.condition,basePrice:t.price,entryId:t.entryId,modelKey:T.model,goodPrice:d?.price??null,goodEntryId:d?.entryId??null};Te(k);const N=U(g.type,t.condition),y=q(g.type,t.condition);N.length>0||y?(H([]),Z(""),X(""),n(s.FAULTS)):g.accessoryOptions?(G([]),n(s.ACCESSORIES)):g.extraAccessoryOptions?(we([]),ve(""),n(s.EXTRAS)):oe(k,[],{faultDeductionTotal:0,appliedFaults:[],pendingReviewFaults:[]})}function nt(t){Ae(t),g.accessoryOptions?(G([]),n(s.ACCESSORIES)):g.extraAccessoryOptions?(we([]),ve(""),n(s.EXTRAS)):oe(P,[],t)}function at(){const t=U(g?.type,P?.conditionRaw),o=t.filter(h=>h.type==="checkbox"),d=t.find(h=>h.type==="battery_threshold"),k=o.filter(h=>Se.includes(h.key)),N=[],y=[];let C=0;for(const h of k)h.deduction==null?y.push({key:h.key,label:h.label}):(N.push({key:h.key,label:h.label,deduction:h.deduction}),C+=h.deduction);if(d&&J!==""){const h=Number(J);if(Number.isFinite(h)&&h<d.threshold_pct){const E=`${d.label} (reported ${h}%)`;d.deduction==null?y.push({key:d.key,label:E}):(N.push({key:d.key,label:E,deduction:d.deduction}),C+=d.deduction)}}const S=Ee.trim().slice(0,500);q(g?.type,P?.conditionRaw)&&S&&y.push({key:"customer_described_issue",label:`Customer-described issue: "${S}"`}),nt({faultDeductionTotal:C,appliedFaults:N,pendingReviewFaults:y,hasReportedFault:N.length>0||y.length>0,faultDescriptionText:S})}function st(){const t=U(g?.type,P?.conditionRaw),o=q(g?.type,P?.conditionRaw);return t.length>0||o?s.FAULTS:s.QUOTE}function lt(t){fetch("/api/fault-price",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({category:t.categoryType,model:t.model,capacity:t.capacity,condition:t.condition,basePrice:t.basePrice,faults:t.pendingReviewFaults,appliedFaults:t.appliedFaults||[]})}).then(o=>o.ok?o.json():{proposals:[]}).then(o=>{const d=o.proposals||[];d.length!==0&&ee(k=>k.map(N=>{if(N.key!==t.key)return N;const y=[],C=[...N.aiProposedFaults||[]];let S=N.aiFaultDeductionTotal||0;for(const h of N.pendingReviewFaults||[]){const E=d.find(ae=>ae.key===h.key);E&&Number.isFinite(E.deduction)?(C.push({key:h.key,label:h.label,deduction:E.deduction,reasoning:E.reasoning||""}),S+=E.deduction):y.push(h)}return{...N,pendingReviewFaults:y,aiProposedFaults:C,aiFaultDeductionTotal:S}}))}).catch(()=>{})}function oe(t,o,d,F){const k=g?.accessoryOptions,N=k&&i?.accessoryBonus?.[k.settingsKey]||{},y=(k?.options||[]).filter(O=>o.includes(O.key)).map(O=>({key:O.key,label:O.label,bonus:Number(N[O.key])||0})),C=y.reduce((O,mt)=>O+mt.bonus,0),{faultDeductionTotal:S=0,appliedFaults:h=[],pendingReviewFaults:E=[],hasReportedFault:ae=!1,faultDescriptionText:dt=""}=d||{},Re=t.goodPrice!=null&&ae,ut=Re?t.goodPrice:t.basePrice,pt=Re?t.goodEntryId:t.entryId,{selectedExtras:eo=[],extrasText:to=""}=F||{},Be={...t,basePrice:ut,entryId:pt,accessories:y,accessoryBonusTotal:C,faultDeductionTotal:S,appliedFaults:h,pendingReviewFaults:E,faultDescription:dt,aiFaultDeductionTotal:0,aiProposedFaults:[],extras:eo.map(O=>({key:O.key,label:O.label,value:0,pending:!0})),extrasText:to,extrasTotalValue:0};ee(O=>[...O,Be]),(eo.length>0||to)&&yt_extraPrice(Be),E.length>0&&lt(Be),Te(null),G([]),H([]),Z(""),X(""),Ae({faultDeductionTotal:0,appliedFaults:[],pendingReviewFaults:[]}),we([]),ve(""),z(null),v(null),c(null),R(null),n(s.CATEGORY)}function yt_extraPrice(t){const F=g?.extraAccessoryOptions;if(!F)return;fetch("/api/extra-price",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({category:t.categoryType,model:t.model,capacity:t.capacity,extras:t.extras.map(o=>({key:o.key,label:o.label})),extrasText:t.extrasText||""})}).then(o=>o.ok?o.json():{estimates:[]}).then(o=>{const d=o.estimates||[];d.length!==0&&ee(k=>k.map(N=>{if(N.key!==t.key)return N;const y=N.extras.map(S=>{const h=d.find(E=>E.key===S.key);return h?{...S,value:h.value,reasoning:h.reasoning||"",pending:!1}:S}),C=d.filter(S=>S.key.startsWith("freetext_item_")).map(S=>({key:S.key,label:S.label,value:S.value,reasoning:S.reasoning||"",pending:!1}));return{...N,extras:[...y,...C],extrasTotalValue:[...y,...C].reduce((S,h)=>S+h.value,0)}}))}).catch(()=>{})}function it(t){ee(o=>o.filter(d=>d.key!==t))}function Ie(t,o){const d=t==="selfie"?He:Qe,k=t==="selfie"?"selfiePath":"idDocumentPath";if(!o)return;d({status:"uploading",fileName:o.name,error:null});const N=(o.name.split(".").pop()||"jpg").toLowerCase();fetch("/api/upload-url",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({fileExt:N})}).then(y=>y.json()).then(({uploadUrl:y,path:C,error:S})=>{if(S)throw new Error(S);return fetch(y,{method:"PUT",headers:{"Content-Type":o.type||"application/octet-stream"},body:o}).then(h=>{if(!h.ok)throw new Error("Upload failed");return C})}).then(y=>{Fe(C=>({...C,[k]:y})),d({status:"done",fileName:o.name,error:null})}).catch(y=>d({status:"error",fileName:o.name,error:y.message}))}const rt=D.reduce((t,o)=>t+Math.max(0,o.basePrice+o.accessoryBonusTotal+(o.extrasTotalValue||0)-(o.faultDeductionTotal||0)-(o.aiFaultDeductionTotal||0)),0),ne=se(()=>i?[{key:"consignment",pct:i.consignmentPct,shortLabel:"Epic Deals Consignment",label:`Epic Deals Consignment (${i.consignmentPct}% Extra)`,helper:`If you don't mind waiting for your payment, consignment is for you. Average sale period is around 13 days, and you'll get an extra ${i.consignmentPct}% for the wait.`},{key:"voucher",pct:i.voucherPct,shortLabel:"Epic Deals Voucher",label:`Epic Deals Voucher (${i.voucherPct}% Extra!)`,helper:"The biggest bonus we offer, redeemable in our online store on whatever you like."},{key:"eft",pct:0,shortLabel:"EFT",label:"EFT",helper:"Paid as soon as we've tested your device, no bonus, straight into your bank account."}]:[],[i]),_e=ne.find(t=>t.key===M)?.pct||0,W=Math.round(rt*(1+_e/100)*100)/100;function ct(t){t.preventDefault(),Pe(!0),L(null),fetch(V("/api/lead"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:D.map(o=>({type:o.type,categoryType:o.categoryType,model:o.model,modelKey:o.modelKey,capacity:o.capacity,condition:o.conditionRaw,price:o.basePrice,entryId:o.entryId,accessories:o.accessories,accessoryBonusTotal:o.accessoryBonusTotal,faultDeductionTotal:o.faultDeductionTotal||0,appliedFaults:o.appliedFaults||[],pendingReviewFaults:o.pendingReviewFaults||[],aiFaultDeductionTotal:o.aiFaultDeductionTotal||0,aiProposedFaults:o.aiProposedFaults||[],faultDescription:o.faultDescription||"",extras:o.extras||[],extrasText:o.extrasText||"",extrasTotalValue:o.extrasTotalValue||0})),quotedTotal:W,paymentPreference:M,paymentBonusPct:_e,...Oe,renderedAt:Le.current})}).then(o=>o.json()).then(o=>{if(o.error)throw new Error(o.error);Xe(o.id),n(s.DONE)}).catch(o=>L(o.message)).finally(()=>Pe(!1))}return<div ref={te}className="mx-auto w-full max-w-xl px-4 py-6 font-sans">
      <Nt/>

      {e!==s.DONE&&<Ct step={e}/>}

      {D.length>0&&e!==s.DONE&&e!==s.REVEAL&&e!==s.CALCULATING&&<Tt items={D}onRemove={it}/>}

      {De&&<p className="mb-4 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{De}</p>}

      <div key={e}className="step-enter">
        {e===s.CATEGORY&&<Et categories={a}loading={f}onChoose={et}hasItems={D.length>0}onProceed={()=>n(s.PAYMENT)}/>}

        {e===s.MODEL&&<At category={g}models={r}loading={We}search={A}onSearch={x}onChoose={tt}onBack={()=>n(s.CATEGORY)}/>}

        {e===s.QUOTE&&<Dt model={T}capacities={j}activeCapacity={w}onChooseCapacity={R}onChooseCondition={ot}onBack={()=>n(s.MODEL)}/>}

        {e===s.FAULTS&&<Ft faultRules={U(g?.type,P?.conditionRaw)}selectedFaultKeys={Se}onToggleFault={t=>H(o=>o.includes(t)?o.filter(d=>d!==t):[...o,t])}batteryPctInput={J}onBatteryPctChange={Z}showFreeText={q(g?.type,P?.conditionRaw)}faultDescription={Ee}onFaultDescriptionChange={X}onContinue={at}onBack={()=>n(s.QUOTE)}/>}

        {e===s.ACCESSORIES&&<Ot config={g.accessoryOptions}selected={ze}onToggle={t=>G(o=>{if(t==="__none__")return["__none__"];const d=o.filter(k=>k!=="__none__");return d.includes(t)?d.filter(k=>k!==t):[...d,t]})}onContinue={()=>{if(g.extraAccessoryOptions){we([]),ve(""),n(s.EXTRAS)}else oe(P,ze,Ue)}}onBack={()=>n(st())}/>}

        {e===s.EXTRAS&&<Xt config={g.extraAccessoryOptions}selected={ke}onToggle={t=>we(o=>o.includes(t)?o.filter(d=>d!==t):[...o,t])}freeText={Ce}onFreeTextChange={ve}onContinue={()=>{const t=ke.map(o=>{const d=g.extraAccessoryOptions.options.find(k=>k.key===o);return d?{key:d.key,label:d.label}:null}).filter(Boolean);oe(P,ze,Ue,{selectedExtras:t,extrasText:Ce})}}onBack={()=>g.accessoryOptions?n(s.ACCESSORIES):n(st())}onSkip={()=>oe(P,ze,Ue)}/>}

        {e===s.PAYMENT&&<Pt options={ne}selected={M}onSelect={qe}onContinue={()=>n(s.CALCULATING)}onBack={()=>n(s.CATEGORY)}/>}

        {e===s.CALCULATING&&<Lt onDone={()=>n(s.REVEAL)}/>}

        {e===s.REVEAL&&<It total={W}items={D}paymentLabel={ne.find(t=>t.key===M)?.shortLabel}onContinue={()=>n(s.DETAILS)}onBack={()=>n(s.PAYMENT)}/>}

        {e===s.DETAILS&&<Mt form={Oe}setForm={Fe}onSubmit={ct}submitting={Je}onBack={()=>n(s.REVEAL)}total={W}paymentPreference={M}idUpload={Ve}onIdFile={t=>Ie("id",t)}selfieUpload={Ke}onSelfieFile={t=>Ie("selfie",t)}/>}

        {e===s.DONE&&<$t leadId={Ze}total={W}items={D}/>}
      </div>
    </div>}function Nt(){const[e,n]=m(0),[a,l]=m(!1),f=le(null);function p(){n(i=>i+1),f.current&&clearTimeout(f.current),f.current=setTimeout(()=>n(0),1500)}return _(()=>{if(e<5)return;l(!0),n(0);const i=setTimeout(()=>l(!1),2800);return()=>clearTimeout(i)},[e]),<div className="relative mb-6">
      <button type="button"onClick={p}aria-label="Epic Deals"className="mb-3 h-1 w-12 origin-left rounded-full bg-[#00a2ff] transition-transform hover:scale-x-125"/>
      {a&&<p className="egg-pop absolute left-16 top-0 max-w-[220px] text-xs font-medium text-[#00a2ff]">
          ð You found the secret. There&apos;s no bonus, but we like your curiosity.
        </p>}
      <h1 className="text-2xl font-bold text-zinc-900">Get an instant offer</h1>
      <p className="mt-1 text-sm text-zinc-500">
        Pick what you&apos;re selling below, no waiting, no haggling, no obligation to sell.
      </p>
    </div>}function Ct({step:e}){const n=ie.indexOf($e[e]||e);return<div className="mb-5">
      <div className="flex items-center gap-1.5">
        {ie.map((a,l)=><div key={a}className={`h-1.5 flex-1 rounded-full transition-colors ${l<=n?"bg-[#00a2ff]":"bg-zinc-200"}`}/>)}
      </div>
      <p className="mt-1.5 text-xs font-medium text-zinc-400">
        Step {n+1} of {ie.length}, {ht[$e[e]||e]}
      </p>
    </div>}function Tt({items:e,onRemove:n}){return<div className="mb-6 overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
      <div className="flex items-center justify-between px-4 py-3">
        <p className="text-sm font-semibold text-zinc-900">Your items</p>
        <span className="rounded-full bg-[#00a2ff]/10 px-2.5 py-1 text-xs font-semibold text-[#00a2ff]">
          {e.length} item{e.length===1?"":"s"}
        </span>
      </div>
      <ul>
        {e.map(a=><li key={a.key}className="item-in flex items-center gap-3 border-t border-zinc-100 px-4 py-3">
            <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${Q[a.categoryType]?.bg||"bg-[#00a2ff]/10"} ${Q[a.categoryType]?.text||"text-[#00a2ff]"}`}>
              <span className="h-4 w-4">{je[a.categoryType]}</span>
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-medium text-zinc-900">
                {a.model} {a.capacity!=="N/A"?`(${a.capacity})`:""}
              </span>
              <span className="block truncate text-xs text-zinc-500">
                {a.condition}
                {a.accessories?.length>0&&` \xB7 ${a.accessories.map(l=>l.label).join(", ")}`}
              </span>
              {(a.appliedFaults?.length>0||a.aiProposedFaults?.length>0||a.pendingReviewFaults?.length>0)&&<span className="block text-xs text-red-500">
                  {[...(a.appliedFaults||[]).map(l=>l.label),...(a.aiProposedFaults||[]).map(l=>`${l.label} (estimate, pending review)`),...(a.pendingReviewFaults||[]).map(l=>`${l.label} (pending review)`)].join(", ")}
                </span>}
              {a.extras?.length>0&&<span className="block text-xs text-emerald-600">
                  {a.extras.map(l=>l.pending?`${l.label} (estimating...)`:`${l.label} (+${B(l.value)})`).join(", ")}
                </span>}
            </span>
            <button onClick={()=>n(a.key)}type="button"aria-label={`Remove ${a.model}`}className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-zinc-400 transition-colors hover:bg-red-50 hover:text-red-500">
              <svg viewBox="0 0 24 24"className="h-3.5 w-3.5"fill="none"stroke="currentColor"strokeWidth="2"strokeLinecap="round">
                <line x1="6"y1="6"x2="18"y2="18"/>
                <line x1="18"y1="6"x2="6"y2="18"/>
              </svg>
            </button>
          </li>)}
      </ul>
      <p className="border-t border-zinc-100 px-4 py-2.5 text-xs text-zinc-500">
        {e.length>=4?"Officially a clear-out. ":""}
        Your offer will be calculated once you&apos;ve picked a payment option.
      </p>
    </div>}function Ne({onClick:e,children:n,sub:a,icon:l,iconBg:f,iconText:p,dot:i}){return<button type="button"onClick={e}className="group flex w-full items-center justify-between rounded-xl border border-zinc-200 bg-white px-4 py-3.5 text-left shadow-sm transition hover:border-[#00a2ff] hover:shadow-md active:scale-[0.99]">
      <span className="flex items-center gap-3">
        {l&&<span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-transform duration-200 group-hover:-rotate-6 group-hover:scale-110 ${f||"bg-[#00a2ff]/10"} ${p||"text-[#00a2ff]"}`}>
            <span className="h-5 w-5">{l}</span>
          </span>}
        {i&&<span className="h-2.5 w-2.5 shrink-0 rounded-full"style={{backgroundColor:i}}/>}
        <span className="font-medium text-zinc-900">{n}</span>
      </span>
      {a&&<span className="text-sm text-zinc-500">{a}</span>}
    </button>}function St({onClick:e,label:n,explainer:a,dot:l}){return<button type="button"onClick={e}className="group flex w-full items-start gap-3 rounded-xl border border-zinc-200 bg-white px-4 py-3.5 text-left shadow-sm transition hover:border-[#00a2ff] hover:shadow-md active:scale-[0.99]">
      {l&&<span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full"style={{backgroundColor:l}}/>}
      <span className="min-w-0">
        <span className="block font-medium text-zinc-900">{n}</span>
        {a&&<span className="mt-0.5 block text-xs text-zinc-500">{a}</span>}
      </span>
    </button>}function Et({categories:e,loading:n,onChoose:a,hasItems:l,onProceed:f}){return n?<Ce rows={4}/>:!e||e.length===0?<p className="text-sm text-zinc-500">No products available right now, please check back soon.</p>:<div className="space-y-2">
      {l&&<button type="button"onClick={f}className="mb-4 w-full rounded-xl bg-[#00a2ff] px-4 py-3.5 font-semibold text-white shadow-sm transition hover:brightness-95 hover:shadow-[0_0_20px_rgba(0,162,255,0.35)]">
          Continue to get your offer
        </button>}
      <p className="mb-2 text-sm font-medium text-zinc-600">
        {l?"Or add another item":"What would you like to sell?"}
      </p>
      {e.map(p=><Ne key={p.type}onClick={()=>a(p)}icon={je[p.type]}iconBg={Q[p.type]?.bg}iconText={Q[p.type]?.text}>
          {p.label}
        </Ne>)}
    </div>}function At({category:e,models:n,loading:a,search:l,onSearch:f,onChoose:p,onBack:i}){const u=n?.filter(r=>r.label.toLowerCase().includes(l.trim().toLowerCase()));return<div className="space-y-2">
      <I onClick={i}label="Back"/>
      <p className="mb-2 text-sm font-medium text-zinc-600">Which {e.label} do you have?</p>
      {!a&&n&&n.length>8&&<input type="text"autoFocus value={l}onChange={r=>f(r.target.value)}placeholder={`Search ${n.length} ${e.label} modelsâ¦`}className="mb-2 w-full rounded-xl border border-zinc-200 bg-white px-4 py-3 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]"/>}
      {a&&<Ce rows={5}/>}
      {!a&&u?.map(r=><Ne key={r.model}onClick={()=>p(r)}>
            {r.label}
          </Ne>)}
      {!a&&u&&u.length===0&&<p className="px-1 py-4 text-sm text-zinc-500">
          No match for &quot;{l}&quot;, try a shorter search, or go back and check the category.
        </p>}
    </div>}function Dt({model:e,capacities:n,activeCapacity:a,onChooseCapacity:l,onChooseCondition:f,onBack:p}){const i=!a&&n?.length>1;return<div className="space-y-2">
      <I onClick={p}label="Back"/>
      {i&&<>
          <p className="mb-2 text-sm font-medium text-zinc-600">{e.label}, storage size?</p>
          {n.map(u=><Ne key={u.capacity}onClick={()=>l(u)}>
              {u.capacity}
            </Ne>)}
        </>}
      {a&&<>
          <p className="mb-2 text-sm font-medium text-zinc-600">
            {e.label} {a.capacity!=="N/A"?`(${a.capacity})`:""}, what condition?
          </p>
          {a.conditions.map(u=><St key={u.condition}onClick={()=>f(u)}dot={xt[u.condition]||"#9ca3af"}label={u.conditionLabel}explainer={gt[u.condition]}/>)}
        </>}
    </div>}function Ot({config:e,selected:n,onToggle:a,onContinue:l,onBack:f}){const p=n.includes("__none__"),i=n.length>0;return<div className="space-y-2">
      <I onClick={f}label="Back"/>
      <p className="mb-2 text-sm font-medium text-zinc-600">{e.groupLabel}</p>
      <K checked={p}onClick={()=>a("__none__")}>
        None
      </K>
      {e.options.map(u=><K key={u.key}checked={!p&&n.includes(u.key)}onClick={()=>a(u.key)}>
          {u.label}
        </K>)}
      <p className="px-1 pt-1 text-xs text-zinc-500">
        Select all the original, undamaged accessories you&apos;d like to include, in good cosmetic and fully
        working condition.
      </p>
      <button type="button"disabled={!i}onClick={l}className="mt-4 w-full rounded-xl bg-[#00a2ff] px-4 py-3.5 font-semibold text-white shadow-sm transition hover:brightness-95 hover:shadow-[0_0_20px_rgba(0,162,255,0.35)] disabled:opacity-60 disabled:hover:shadow-none">
        Continue
      </button>
    </div>}function Xt({config:e,selected:n,onToggle:a,freeText:l,onFreeTextChange:f,onContinue:p,onBack:i,onSkip:u}){const r=n.length>0||l.trim().length>0;return<div className="space-y-2">
      <I onClick={i}label="Back"/>
      <p className="mb-2 text-sm font-medium text-zinc-600">{e.groupLabel}</p>
      <p className="mb-3 text-xs text-zinc-500">Got extra accessories to include? We&apos;ll estimate what we can offer for each one and add it to your total.</p>
      {e.options.map(b=><K key={b.key}checked={n.includes(b.key)}onClick={()=>a(b.key)}>
          {b.label}
        </K>)}
      <div className="mt-3">
        <label className="mb-1 block text-xs font-medium text-zinc-600">Anything else?</label>
        <textarea value={l}onChange={b=>f(b.target.value)}placeholder="e.g. 3 extra games, a VR headset..."maxLength={500}rows={2}className="w-full rounded-xl border border-zinc-200 bg-white px-4 py-3 text-sm text-zinc-900 placeholder-zinc-400 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]"/>
      </div>
      <button type="button"onClick={p}disabled={!r}className="mt-4 w-full rounded-xl bg-[#00a2ff] px-4 py-3.5 font-semibold text-white shadow-sm transition hover:brightness-95 hover:shadow-[0_0_20px_rgba(0,162,255,0.35)] disabled:opacity-60 disabled:hover:shadow-none">
        Continue with extras
      </button>
      <button type="button"onClick={u}className="mt-1 w-full rounded-xl border border-zinc-200 bg-white px-4 py-3 text-sm font-medium text-zinc-600 shadow-sm transition hover:bg-zinc-50">
        Skip, no extras
      </button>
    </div>}function Ft({faultRules:e,selectedFaultKeys:n,onToggleFault:a,batteryPctInput:l,onBatteryPctChange:f,showFreeText:p,faultDescription:i,onFaultDescriptionChange:u,onContinue:r,onBack:b}){const A=e.find(v=>v.type==="battery_threshold"),x=e.filter(v=>v.type==="checkbox"),g=x.find(v=>v.decline&&n.includes(v.key)),Un=n.length>0||!!(p&&i.trim()),[z,T]=m(!!A);return A&&z?<div className="space-y-2">
        <I onClick={b}label="Back"/>
        <button type="button"onClick={r}className={`mb-1 flex w-full items-center gap-2 rounded-xl border-2 px-4 py-3.5 text-left font-semibold shadow-sm transition ${Un?"border-zinc-200 bg-white text-zinc-600 hover:border-[#00a2ff]":"border-[#00a2ff] bg-[#00a2ff]/5 text-[#00a2ff] hover:bg-[#00a2ff]/10"}`}>
          <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 transition-colors ${Un?"border-zinc-300":"border-[#00a2ff] bg-[#00a2ff]"}`}>
            {!Un&&<svg viewBox="0 0 24 24"className="h-3.5 w-3.5 text-white"fill="none"stroke="currentColor"strokeWidth="3">
              <polyline points="20 6 9 17 4 12"/>
            </svg>}
          </span>
          No faults, it works perfectly
        </button>
        <p className="mb-2 text-sm font-medium text-zinc-600">What&apos;s the battery health?</p>
        <div className="rounded-xl border border-zinc-200 bg-white px-4 py-3.5 shadow-sm">
          <label className="mb-1 block text-sm font-medium text-zinc-900">Battery health %</label>
          <p className="mb-2 text-xs text-zinc-500">
            Check Settings â Battery â Battery Health on the device. Leave blank if you&apos;re not sure.
          </p>
          <input type="number"inputMode="numeric"min="0"max="100"value={l}onChange={v=>f(v.target.value)}placeholder="e.g. 87"className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]"/>
        </div>
        <p className="px-1 pt-1 text-xs text-zinc-500">Not sure, or it&apos;s fine? Just hit continue.</p>
        <button type="button"onClick={()=>T(!1)}className="mt-4 w-full rounded-xl bg-[#00a2ff] px-4 py-3.5 font-semibold text-white shadow-sm transition hover:brightness-95 hover:shadow-[0_0_20px_rgba(0,162,255,0.35)]">
          Continue
        </button>
      </div>:<div className="space-y-2">
      <I onClick={A?()=>T(!0):b}label="Back"/>
      <button type="button"onClick={r}className={`mb-1 flex w-full items-center gap-2 rounded-xl border-2 px-4 py-3.5 text-left font-semibold shadow-sm transition ${Un?"border-zinc-200 bg-white text-zinc-600 hover:border-[#00a2ff]":"border-[#00a2ff] bg-[#00a2ff]/5 text-[#00a2ff] hover:bg-[#00a2ff]/10"}`}>
        <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 transition-colors ${Un?"border-zinc-300":"border-[#00a2ff] bg-[#00a2ff]"}`}>
          {!Un&&<svg viewBox="0 0 24 24"className="h-3.5 w-3.5 text-white"fill="none"stroke="currentColor"strokeWidth="3">
            <polyline points="20 6 9 17 4 12"/>
          </svg>}
        </span>
        No faults, it works perfectly
      </button>
      <p className="mb-2 text-sm font-medium text-zinc-600">
        {A?"Any other faults we should know about?":"Any faults we should know about?"}
      </p>

      {x.map(v=><K key={v.key}checked={n.includes(v.key)}onClick={()=>a(v.key)}>
          {v.label}
        </K>)}

      {p&&<div className="rounded-xl border border-zinc-200 bg-white px-4 py-3.5 shadow-sm">
          <label className="mb-1 block text-sm font-medium text-zinc-900">Describe what&apos;s wrong (optional)</label>
          <textarea value={i}onChange={v=>u(v.target.value)}rows={3}maxLength={500}placeholder="e.g. won&apos;t power on, three dead keys, hinge is looseâ¦"className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]"/>
          <p className="mt-1 text-xs text-zinc-500">
            The more detail you give us, the better we can price it, our system reviews this to propose a fair
            deduction.
          </p>
        </div>}

      {g?<p className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
          Sorry, we&apos;re not able to buy back a device in this condition right now. Untick that above to continue
          with a different fault, or go back and choose a different condition.
        </p>:<p className="px-1 pt-1 text-xs text-zinc-500">
          Select anything that applies, we&apos;ll adjust your offer to reflect it. Nothing to report? Just hit
          continue.
        </p>}

      <button type="button"disabled={!!g}onClick={r}className="mt-4 w-full rounded-xl bg-[#00a2ff] px-4 py-3.5 font-semibold text-white shadow-sm transition hover:brightness-95 hover:shadow-[0_0_20px_rgba(0,162,255,0.35)] disabled:opacity-60 disabled:hover:shadow-none">
        Continue
      </button>
    </div>}function K({checked:e,onClick:n,children:a}){return<button type="button"onClick={n}className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3.5 text-left shadow-sm transition active:scale-[0.99] ${e?"border-[#00a2ff] bg-[#00a2ff]/5":"border-zinc-200 bg-white hover:border-[#00a2ff]"}`}>
      <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 transition-colors ${e?"border-[#00a2ff] bg-[#00a2ff]":"border-zinc-300"}`}>
        {e&&<svg viewBox="0 0 24 24"className="check-pop h-3.5 w-3.5 text-white"fill="none"stroke="currentColor"strokeWidth="3">
            <polyline points="20 6 9 17 4 12"/>
          </svg>}
      </span>
      <span className="font-medium text-zinc-900">{a}</span>
    </button>}function Pt({options:e,selected:n,onSelect:a,onContinue:l,onBack:f}){if(e.length===0)return<Ce rows={3}/>;const p=e.find(i=>i.key===n)||e[0];return<div className="space-y-2">
      <I onClick={f}label="Back"/>
      <p className="mb-2 text-sm font-medium text-zinc-600">How would you like to be paid?</p>
      {e.map(i=><K key={i.key}checked={i.key===n}onClick={()=>a(i.key)}>
          {i.label}
        </K>)}
      <p className="px-1 pt-1 text-xs text-zinc-500">{p.helper}</p>
      <button type="button"onClick={l}className="mt-4 w-full rounded-xl bg-[#00a2ff] px-4 py-3.5 font-semibold text-white shadow-sm transition hover:brightness-95 hover:shadow-[0_0_20px_rgba(0,162,255,0.35)]">
        Calculate Offer
      </button>
    </div>}const $=[{text:"Crunching the numbersâ¦",duration:1500},{text:"Checking today's going rateâ¦",duration:1600},{text:"Comparing against today's market (no lowballing here)â¦",duration:1900},{text:"Making sure you're not leaving money on the tableâ¦",duration:1900},{text:"Politely arguing with our pricing botâ¦",duration:1700},{text:"Weighing up your accessories (yes, the cable counts)â¦",duration:1900},{text:"Double-checking everything adds upâ¦",duration:1700},{text:"Almost thereâ¦",duration:1300},{text:"Locking in your best offerâ¦",duration:1500}];function Lt({onDone:e}){const[n,a]=m(0);return _(()=>{const l=[];let f=0;for(let i=1;i<$.length;i++)f+=$[i-1].duration,l.push(setTimeout(()=>a(i),f));f+=$[$.length-1].duration;const p=setTimeout(e,f);return()=>{l.forEach(clearTimeout),clearTimeout(p)}},[e]),<div className="flex flex-col items-center justify-center gap-5 rounded-2xl border border-[#00a2ff]/30 bg-gradient-to-b from-[#00a2ff]/10 to-white px-4 py-20 text-center">
      <span className="h-12 w-12 animate-spin rounded-full border-4 border-[#00a2ff]/20 border-t-[#00a2ff]"/>
      <p key={n}className="msg-in text-sm font-medium text-zinc-600"aria-live="polite">
        {$[n].text}
      </p>
    </div>}function It({total:e,items:n,paymentLabel:a,onContinue:l,onBack:f}){const[p,i]=m(0),u=se(()=>Array.from({length:22}).map((r,b)=>({id:b,left:Math.random()*100,delay:Math.random()*.4,duration:1.1+Math.random()*.7,color:Ge[b%Ge.length],rotate:Math.random()*360})),[]);return _(()=>{let r;const A=performance.now();function x(g){const z=Math.min(1,(g-A)/3e3),T=1-Math.pow(1-z,3);i(e*T),z<1&&(r=requestAnimationFrame(x))}return r=requestAnimationFrame(x),()=>cancelAnimationFrame(r)},[e]),<div className="space-y-4">
      <I onClick={f}label="Back"/>
      <div className="relative overflow-hidden rounded-2xl border border-[#00a2ff]/30 bg-gradient-to-b from-[#00a2ff]/10 to-white px-4 py-10 text-center">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          {u.map(r=><span key={r.id}className="reveal-confetti-piece absolute top-0 h-2 w-2 rounded-sm"style={{left:`${r.left}%`,backgroundColor:r.color,animationDelay:`${r.delay}s`,animationDuration:`${r.duration}s`,transform:`rotate(${r.rotate}deg)`}}/>)}
        </div>
        <p className="relative text-sm font-semibold uppercase tracking-wide text-[#00a2ff]">
          ð We&apos;ve put together an Epic offer for you
        </p>
        {n.length>1&&<ul className="relative mt-4 space-y-1 text-left">
            {n.map(r=><li key={r.key}className="flex items-start justify-between gap-2 text-sm">
                <span className="text-zinc-600">
                  {r.model} {r.capacity!=="N/A"?`(${r.capacity})`:""}, {r.condition}
                  {r.accessories?.length>0&&<span className="block text-xs text-zinc-400">
                      {r.accessories.map(b=>b.label).join(", ")}
                    </span>}
                  {(r.appliedFaults?.length>0||r.aiProposedFaults?.length>0)&&<span className="block text-xs text-red-500">
                      {[...r.appliedFaults.map(b=>`${b.label} (-${B(b.deduction)})`),...(r.aiProposedFaults||[]).map(b=>`${b.label} (-${B(b.deduction)}, pending review)`)].join(", ")}
                    </span>}
                  {r.extras?.filter(b=>b.value>0).length>0&&<span className="block text-xs text-emerald-600">
                      Extras: {r.extras.filter(b=>b.value>0).map(b=>`${b.label} (+${B(b.value)})`).join(", ")}
                    </span>}
                </span>
                <span className="shrink-0 font-medium text-zinc-900">
                  {B(Math.max(0,r.basePrice+r.accessoryBonusTotal+(r.extrasTotalValue||0)-(r.faultDeductionTotal||0)-(r.aiFaultDeductionTotal||0)))}
                </span>
              </li>)}
          </ul>}
        <div className="relative mt-3 inline-flex items-center justify-center">
          <span className="reveal-pulse-ring absolute h-24 w-24 rounded-full border-2 border-[#00a2ff]"/>
          <p className="reveal-amount relative text-5xl font-extrabold tracking-tight text-zinc-900">
            {B(p)}
          </p>
        </div>
        <p className="relative mt-3 text-sm text-zinc-500">
          Paid via {a}, that&apos;s your total, all in, no surprises.
        </p>
        {e>=2e4&&<p className="relative mt-1 text-xs font-semibold text-[#00a2ff]">
            That&apos;s a proper number. Nice work.
          </p>}
      </div>
      <button type="button"onClick={l}className="w-full rounded-xl bg-[#00a2ff] px-4 py-3.5 font-semibold text-white shadow-sm transition hover:brightness-95 hover:shadow-[0_0_20px_rgba(0,162,255,0.35)]">
        Continue
      </button>
    </div>}const _t=["First National Bank (FNB)","Absa","Capitec","Nedbank","Discovery","Investec","Standard Bank","Other"],Rt=["Cheque","Savings","Current","Credit","Other"],Bt=["Gauteng","Free State","Eastern Cape","KwaZulu-Natal","Limpopo","Mpumalanga","Northern Cape","North West","Western Cape"];function Mt({form:e,setForm:n,onSubmit:a,submitting:l,onBack:f,total:p,paymentPreference:i,idUpload:u,onIdFile:r,selfieUpload:b,onSelfieFile:A}){function x(c){return w=>n(R=>({...R,[c]:w.target.value}))}const g=i==="eft"||i==="consignment",z=ft(e.idNumber),T=bt(e.preferredCollectionDate),[dn,fn]=m(!1),Wn=e.idNumber.trim().replace(/\s/g,""),Yn=/^\d+$/.test(Wn),Kn=Yn?Wn.length===13?"That ID number doesn't check out, please double-check it.":"Should be 13 digits for an SA ID number, or 6-9 characters for a passport number.":"That doesn't look like a valid SA ID or passport number, please double-check it.",v=se(()=>{const c=new Date;return c.setDate(c.getDate()+1),`${c.getFullYear()}-${String(c.getMonth()+1).padStart(2,"0")}-${String(c.getDate()).padStart(2,"0")}`},[]),j=u.status==="done"&&b.status==="done"&&z.valid&&T&&e.ageConfirmed&&e.termsAccepted&&e.privacyAccepted&&(!g||e.bankName&&e.accountType&&e.branchCode&&e.accountNumber)&&!l;return<form onSubmit={a}className="space-y-3">
      <I onClick={f}label="Back to my offer"/>
      <p className="mb-1 text-sm font-medium text-zinc-600">
        Your offer: <span className="font-bold text-zinc-900">{B(p)}</span>. Almost done, where should we collect from?
      </p>
      <div className="mb-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-500">
        <span>ð Encrypted &amp; secure</span>
        <span>ð Second-Hand Goods Act compliant</span>
        <span>ð³ Multiple payout options</span>
      </div>
      <F label="Full name"required value={e.fullName}onChange={x("fullName")}/>
      <F label="Cellphone number"required type="tel"value={e.phone}onChange={x("phone")}/>
      <F label="Email"type="email"value={e.email}onChange={x("email")}/>
      <F label="Street address"value={e.address}onChange={x("address")}/>
      <div className="grid grid-cols-2 gap-3">
        <F label="Suburb"value={e.suburb}onChange={x("suburb")}/>
        <F label="City"value={e.city}onChange={x("city")}/>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1 block text-sm font-medium text-zinc-700">Province</label>
          <select value={e.province}onChange={x("province")}className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]">
            <option value="">Select a province</option>
            {Bt.map(c=><option key={c}value={c}>
                {c}
              </option>)}
          </select>
        </div>
        <F label="Postal code"value={e.postalCode}onChange={x("postalCode")}/>
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-zinc-700">Is this your residential address?</label>
        <select value={e.residentialAddress?"yes":"no"}onChange={c=>n(w=>({...w,residentialAddress:c.target.value==="yes"}))}className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]">
          <option value="yes">Yes</option>
          <option value="no">No</option>
        </select>
        <p className="mt-1 text-xs text-zinc-500">
          We&apos;re legally required to keep your residential address and ID documents on record for 5 years from the
          transaction date.
        </p>
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-zinc-700">Preferred collection date</label>
        <input type="date"min={v}value={e.preferredCollectionDate}onChange={x("preferredCollectionDate")}className={`w-full rounded-lg border bg-white px-3 py-2 text-sm text-zinc-900 focus:outline-none focus:ring-1 ${e.preferredCollectionDate&&!T?"border-red-300 focus:border-red-400 focus:ring-red-400":"border-zinc-200 focus:border-[#00a2ff] focus:ring-[#00a2ff]"}`}/>
        <p className="mt-1 text-xs text-zinc-500">
          Our couriers only collect on weekdays, not weekends or SA public holidays.
        </p>
        {e.preferredCollectionDate&&!T&&<p className="mt-1 text-xs text-red-600">
            That date&apos;s a weekend or public holiday, our couriers don&apos;t collect then, please pick a weekday.
          </p>}
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-zinc-700">Anything we should know?</label>
        <textarea value={e.notes}onChange={x("notes")}rows={3}className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]"/>
      </div>

      {g&&<div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
            Banking details, for your payout
          </p>
          <p className="mb-2 text-xs text-zinc-500">ð Used only to pay you for this sale.</p>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-zinc-700">
                Bank name <span className="text-red-500">*</span>
              </label>
              <select value={e.bankName}onChange={x("bankName")}className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]">
                <option value="">Select a bank</option>
                {_t.map(c=><option key={c}value={c}>
                    {c}
                  </option>)}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-zinc-700">
                Account type <span className="text-red-500">*</span>
              </label>
              <select value={e.accountType}onChange={x("accountType")}className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]">
                <option value="">Select a type</option>
                {Rt.map(c=><option key={c}value={c}>
                    {c}
                  </option>)}
              </select>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <F label="Branch code"required inputMode="numeric"value={e.branchCode}onChange={c=>n(w=>({...w,branchCode:Me(c.target.value)}))}/>
            <F label="Account number"required inputMode="numeric"value={e.accountNumber}onChange={c=>n(w=>({...w,accountNumber:Me(c.target.value)}))}/>
          </div>
        </div>}

      <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
          Required by law for buying second-hand goods
        </p>
        <div>
          <label className="mb-1 block text-sm font-medium text-zinc-700">
            ID or passport number <span className="text-red-500">*</span>
          </label>
          <input type="text"required value={e.idNumber}onChange={x("idNumber")}onBlur={()=>fn(!0)}className={`w-full rounded-lg border bg-white px-3 py-2 text-sm text-zinc-900 focus:outline-none focus:ring-1 ${dn&&e.idNumber&&!z.valid?"border-red-300 focus:border-red-400 focus:ring-red-400":"border-zinc-200 focus:border-[#00a2ff] focus:ring-[#00a2ff]"}`}/>
          {dn&&e.idNumber&&!z.valid&&<p className="mt-1 text-xs text-red-600">
              {Kn}
            </p>}
        </div>

        <div className="mt-3">
          <label className="mb-1 block text-sm font-medium text-zinc-700">
            Photo of your ID or passport <span className="text-red-500">*</span>
          </label>
          <p className="mb-1 text-xs text-zinc-500">A clear colour photo, no black-and-white copies, showing your photo and ID number.</p>
          <input type="file"accept="image/*,application/pdf"required={u.status!=="done"}onChange={c=>r(c.target.files?.[0])}className="block w-full text-sm text-zinc-600 file:mr-3 file:rounded-lg file:border-0 file:bg-[#00a2ff] file:px-3 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:brightness-95"/>
          {u.status==="uploading"&&<p className="mt-1 text-xs text-zinc-500">Uploading {u.fileName}â¦</p>}
          {u.status==="done"&&<p className="mt-1 text-xs text-green-600">Uploaded, {u.fileName}</p>}
          {u.status==="error"&&<p className="mt-1 text-xs text-red-600">Couldn&apos;t upload that file, {u.error}. Try again.</p>}
        </div>

        <div className="mt-3">
          <label className="mb-1 block text-sm font-medium text-zinc-700">
            A selfie of you <span className="text-red-500">*</span>
          </label>
          <p className="mb-1 text-xs text-zinc-500">
            Face the camera directly with nothing covering your face, so we can confirm it&apos;s really you selling.
          </p>
          <input type="file"accept="image/*"required={b.status!=="done"}onChange={c=>A(c.target.files?.[0])}className="block w-full text-sm text-zinc-600 file:mr-3 file:rounded-lg file:border-0 file:bg-[#00a2ff] file:px-3 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:brightness-95"/>
          {b.status==="uploading"&&<p className="mt-1 text-xs text-zinc-500">Uploading {b.fileName}â¦</p>}
          {b.status==="done"&&<p className="mt-1 text-xs text-green-600">Uploaded, {b.fileName}</p>}
          {b.status==="error"&&<p className="mt-1 text-xs text-red-600">Couldn&apos;t upload that file, {b.error}. Try again.</p>}
        </div>

        <p className="mt-3 text-xs text-zinc-500">
          ð Your ID and selfie are encrypted and only ever used to verify your identity for this sale, as required
          under the Second-Hand Goods Act.
        </p>

        <label className="mt-3 flex items-start gap-2 text-sm text-zinc-700">
          <input type="checkbox"required checked={e.ageConfirmed}onChange={c=>n(w=>({...w,ageConfirmed:c.target.checked}))}className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-[#00a2ff] focus:ring-[#00a2ff]"/>
          <span>
            I confirm I am 18 years or older, that this device is legally mine to sell, and that it is not
            currently on any contract.
          </span>
        </label>

        <label className="mt-3 flex items-start gap-2 text-sm text-zinc-700">
          <input type="checkbox"required checked={e.termsAccepted}onChange={c=>n(w=>({...w,termsAccepted:c.target.checked}))}className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-[#00a2ff] focus:ring-[#00a2ff]"/>
          <span>
            I accept the{" "}
            <a href="https://sellyouriphone.co.za/terms-and-conditions-2/"target="_blank"rel="noreferrer"className="text-[#00a2ff] hover:underline">
              buy-back terms
            </a>{" "}
            and{" "}
            <a href="https://sellyouriphone.co.za/consignment-terms-and-conditions-2/"target="_blank"rel="noreferrer"className="text-[#00a2ff] hover:underline">
              consignment terms
            </a>
            .
          </span>
        </label>

        <label className="mt-3 flex items-start gap-2 text-sm text-zinc-700">
          <input type="checkbox"required checked={e.privacyAccepted}onChange={c=>n(w=>({...w,privacyAccepted:c.target.checked}))}className="mt-0.5 h-4 w-4 rounded border-zinc-300 text-[#00a2ff] focus:ring-[#00a2ff]"/>
          <span>
            I agree to the{" "}
            <a href="https://epicdeals.co.za/privacy-policy/"target="_blank"rel="noreferrer"className="text-[#00a2ff] hover:underline">
              privacy policy
            </a>
            .
          </span>
        </label>
      </div>

      {}
      <div className="hidden"aria-hidden="true">
        <label>
          Website
          <input tabIndex={-1}autoComplete="off"value={e.website}onChange={x("website")}/>
        </label>
      </div>
      <button type="submit"disabled={!j}className="w-full rounded-xl bg-[#00a2ff] px-4 py-3.5 font-semibold text-white shadow-sm transition hover:brightness-95 hover:shadow-[0_0_20px_rgba(0,162,255,0.35)] disabled:opacity-60 disabled:hover:shadow-none">
        {l?"Submittingâ¦":"Let's do it!"}
      </button>
    </form>}const Ye=["We'll take it from here.","Kettle's on, we won't be long.","No further haggling required, promise.","Sit back, we've got this one."];function $t({leadId:e,total:n,items:a}){const[l]=m(()=>Ye[Math.floor(Math.random()*Ye.length)]);return<div className="rounded-xl border border-green-200 bg-green-50 p-5 text-center">
      <p className="text-lg font-semibold text-green-800">Thanks, we&apos;ve got your details!</p>
      <p className="mt-2 text-sm text-green-700">
        Your quoted offer of <span className="font-bold">{B(n)}</span> for {a.length}{" "}
        item{a.length===1?"":"s"} has been submitted{e?` (ref #${e})`:""}. We&apos;ll be in touch
        shortly to arrange collection.
      </p>
      <p className="mt-2 text-xs text-green-600">{l}</p>
    </div>}function F({label:e,required:n,type:a="text",value:l,onChange:f,...p}){return<div>
      <label className="mb-1 block text-sm font-medium text-zinc-700">
        {e} {n&&<span className="text-red-500">*</span>}
      </label>
      <input type={a}required={n}value={l}onChange={f}className="w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-[#00a2ff] focus:outline-none focus:ring-1 focus:ring-[#00a2ff]"{...p}/>
    </div>}function I({onClick:e,label:n}){return<button type="button"onClick={e}className="mb-1 text-sm font-medium text-[#00a2ff] hover:underline">
      â {n}
    </button>}function Ce({rows:e}){return<div className="space-y-2">
      {Array.from({length:e}).map((n,a)=><div key={a}className="skeleton-shimmer h-14 rounded-xl"/>)}
    </div>}
